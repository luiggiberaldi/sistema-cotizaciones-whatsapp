# Reglas del Proyecto - Sistema de Cotización WhatsApp

## Regla de Integridad de Datos

**Nunca modifiques la lógica de cálculo de precios en `QuoteService` sin ejecutar primero `tests/test_quote_service.py`.**

La precisión decimal es crítica. Si tocas algo relacionado con dinero, debes agregar un nuevo caso de prueba que verifique ese cambio específico antes de confirmar el código.

### Procedimiento Obligatorio para Cambios en Cálculos:

1. **Antes de modificar**:
   ```bash
   pytest tests/test_quote_service.py -v
   ```
   Verificar que todos los tests existentes pasen.

2. **Agregar test para el cambio**:
   - Crear un nuevo test case que cubra el escenario específico.
   - Incluir casos edge (decimales, redondeo, valores extremos).

3. **Implementar el cambio**:
   - Modificar la lógica en `QuoteService`.

4. **Verificar**:
   ```bash
   pytest tests/test_quote_service.py -v
   ```
   Todos los tests (antiguos + nuevos) deben pasar.

### Archivos Críticos:
- `src/application/use_cases/quote_service.py` - Lógica de cálculo
- `tests/test_quote_service.py` - Tests de validación

### Ejemplo de Test Requerido:
```python
def test_calculate_total_with_decimals():
    """Verificar precisión decimal en cálculos."""
    items = [
        QuoteItem(product_name="Test", quantity=3, unit_price=10.99, subtotal=32.97)
    ]
    quote = Quote(client_phone="+1234567890", items=items, total=32.97)
    assert quote.total == 32.97  # Exacto, no aproximado
```

---

## Reglas Generales

### 1. Consultar Lecciones Aprendidas
Antes de escribir código nuevo, leer [`docs/LESSONS_LEARNED.md`](../docs/LESSONS_LEARNED.md).

### 2. Arquitectura Hexagonal
- Nunca importar `infrastructure` desde `domain`.
- Casos de uso solo dependen de interfaces.

### 3. Seguridad
- Todas las rutas de escritura deben tener `Depends(get_current_user)`.
- Nunca commitear archivos `.env`.
- Usar Supabase Auth nativo, no crear tabla de usuarios propia.

### 4. Testing
- Ejecutar `pytest` antes de commits importantes.
- Mockear servicios externos en tests.
- Cobertura mínima: 80% en servicios, 100% en casos de uso.

### 5. Variables de Entorno
- Backend: Actualizar `settings.py` y `.env.example` simultáneamente.
- Frontend: Usar prefijo `VITE_` para todas las variables.

---

**Última actualización**: 2026-01-27
