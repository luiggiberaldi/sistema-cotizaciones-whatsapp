"""API de infraestructura."""
