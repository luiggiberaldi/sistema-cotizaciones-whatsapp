"""Adaptadores de base de datos."""
from .supabase_quote_repository import SupabaseQuoteRepository

__all__ = ['SupabaseQuoteRepository']
