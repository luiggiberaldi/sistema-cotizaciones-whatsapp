"""Capa de infraestructura."""
