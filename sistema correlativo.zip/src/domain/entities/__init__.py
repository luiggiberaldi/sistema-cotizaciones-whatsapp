"""Entidades de dominio."""
from .quote import Quote, QuoteItem, QuoteStatus

__all__ = ['Quote', 'QuoteItem', 'QuoteStatus']
