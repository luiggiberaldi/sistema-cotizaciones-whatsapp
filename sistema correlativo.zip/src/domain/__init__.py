"""Capa de dominio."""
