"""Repositorios de dominio (Puertos)."""
from .quote_repository import QuoteRepository

__all__ = ['QuoteRepository']
