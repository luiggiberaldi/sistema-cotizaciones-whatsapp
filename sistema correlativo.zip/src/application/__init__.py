"""Capa de aplicación."""
