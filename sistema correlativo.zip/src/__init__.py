"""Paquete principal de la aplicación."""
